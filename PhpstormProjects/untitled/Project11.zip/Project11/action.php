<?php
header('customers.php');