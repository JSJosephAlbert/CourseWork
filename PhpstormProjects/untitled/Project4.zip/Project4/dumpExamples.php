<?php
$array = ['key'=>'value'];
var_dump($array);
var_export($array);
print_r($array);
?>
